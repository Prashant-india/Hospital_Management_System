package com.hospital.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hospital.entity.Appointment;
import com.hospital.entity.UserDetails;
import com.hospital.service.AppointmentService;
import com.hospital.service.UserDetailsService;

@RestController
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	UserDetailsService userService;
	@Autowired
	AppointmentService appointmentService;

	@PostMapping(value = "/login", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<UserDetails> login(@RequestBody UserLogin userlogin) {
		UserDetails user = userService.login(userlogin.getUserName(), userlogin.getPassword());
		return ResponseEntity.status(200).body(user);
	}

	@PostMapping(value = "/registration", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Boolean> userRegistration(@RequestBody UserDetails userDetails) {
		Boolean created = Boolean.FALSE;
		
		
		try {
			
			userService.addUpdateUser(userDetails);
			created = Boolean.TRUE;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.status(200).body(created);
	}
	
	@GetMapping(value = "/getUsersDetailsById/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<UserDetails> getUsersDetailsById(@PathVariable Long id) {
	UserDetails users=null; 
		try {
			users=userService.getUserById(id);
			
		} catch (Exception e) {

		}
		return ResponseEntity.status(200).body(users);
	}
	
	@GetMapping(value = "/getAllUsers", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<List<UserDetails>> getAllusers() {
		List<UserDetails> allusers = new ArrayList<>();
		try {
			allusers =userService.getAllUsers();
			
		} catch (Exception e) {

		}
		return ResponseEntity.status(200).body(allusers);
	}
	
	@DeleteMapping(value = "/deleteUser/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Boolean> deleteUser(@PathVariable Long id) {
		Boolean isDeleted = Boolean.FALSE;
		try {
			userService.deleteUser(id);
			isDeleted=Boolean.TRUE;
		} catch (Exception e) {

		}
		return ResponseEntity.status(200).body(isDeleted);
	}

	/* appointments */
	
	@GetMapping(value = "/getAppointmentsForDoctor/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<List<Appointment>> getAppointmentsForDoctor(@PathVariable(name = "id") Long id) {
		List<Appointment> appointment = new ArrayList<>();
		try {
			appointment =appointmentService.getAppointmentsForDoctor(id);
			
		} catch (Exception e) {

		}
		return ResponseEntity.status(200).body(appointment);
	}
	
	@GetMapping(value = "/getAppointmentsForPatient/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<List<Appointment>> getAppointmentsForPatient(@PathVariable(name = "id") Long id) {
		List<Appointment> appointment = new ArrayList<>();
		try {
			appointment =appointmentService.getAppointmentsForPatient(id);
			
		} catch (Exception e) {

		}
		return ResponseEntity.status(200).body(appointment);
	}
	
	@PostMapping(value = "/saveAppointment", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	ResponseEntity<Boolean> saveAppointment(@RequestBody Appointment appointment) {
		Boolean created = Boolean.FALSE;
		try {
			appointmentService.saveAppointment(appointment);
			created = Boolean.TRUE;
		} catch (Exception e) {

		}
		return ResponseEntity.status(200).body(created);
	}
	
	
}
