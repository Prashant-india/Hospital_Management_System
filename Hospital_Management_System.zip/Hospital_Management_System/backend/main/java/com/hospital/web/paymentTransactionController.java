package com.hospital.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.entity.orderTransactionDetails;
import com.hospital.service.orderservices;

@RestController
@CrossOrigin(origins = "*")
public class paymentTransactionController {

	@Autowired
	private orderservices orderservices;
	
	@GetMapping("/getTransaction/{amount}")
	public orderTransactionDetails getTransaction(@PathVariable(name="amount") 
	 Double amount)
	{
			return orderservices.orderCreateTransaction(amount);
	}

}
