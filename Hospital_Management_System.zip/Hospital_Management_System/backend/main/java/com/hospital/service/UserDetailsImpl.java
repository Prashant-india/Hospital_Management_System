package com.hospital.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.UserDetailsRepo;
import com.hospital.entity.UserDetails;
@Service
public class UserDetailsImpl implements UserDetailsService{
@Autowired
 UserDetailsRepo userRepository;
	@Override
	public void addUpdateUser(UserDetails userDetails) {
		userRepository.save(userDetails);
		
	}

	@Override
	public void deleteUser(Long id) {
		UserDetails userDetails =  userRepository.getById(id);
		userRepository.delete(userDetails);
		
	}

	@Override
	public UserDetails getUserById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.getById(id);
	}

	@Override
	public List<UserDetails> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public UserDetails login(String username, String password) {
		System.out.println(username+"  "+password);
		
		// TODO Auto-generated method stub
		UserDetails user = userRepository.findByUsername(username).orElse(null);
		if(user!=null) {
			if(user.getPassword().equals(password)) {
				return user;
			}else {
				return user = null;
			}
			}else {
				return null;
			}
		
	}

}
