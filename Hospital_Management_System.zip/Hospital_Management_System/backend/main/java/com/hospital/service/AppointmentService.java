package com.hospital.service;

import java.util.List;

import com.hospital.entity.Appointment;

public interface AppointmentService {

	List<Appointment> getAppointmentsForDoctor(Long docId);
	List<Appointment> getAppointmentsForPatient(Long patientId);
	void saveAppointment(Appointment appointment);
}
