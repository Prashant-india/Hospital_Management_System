package com.hospital.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hospital.entity.UserDetails;

public interface UserDetailsService {

	void addUpdateUser(UserDetails userDetails);
	void deleteUser(Long id);
	UserDetails getUserById(Long id);
	List<UserDetails> getAllUsers();
	UserDetails login(String username,String password);
}
