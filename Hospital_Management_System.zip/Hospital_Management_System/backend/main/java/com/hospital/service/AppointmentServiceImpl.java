package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.AppointmentRepo;
import com.hospital.entity.Appointment;
@Service
public class AppointmentServiceImpl implements AppointmentService{

	@Autowired
	AppointmentRepo repo;
	@Override
	public List<Appointment> getAppointmentsForDoctor(Long docId) {
		
		return repo.findByDoctorId(docId);
	}

	@Override
	public List<Appointment> getAppointmentsForPatient(Long patientId) {
		// TODO Auto-generated method stub
		return repo.findByPatientId(patientId);
	}

	@Override
	public void saveAppointment(Appointment appointment) {
		repo.save(appointment);
		
	}

}
