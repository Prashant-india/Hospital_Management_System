package com.hospital.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hospital.entity.UserDetails;

public class UserDetailsToJsonExample {

    public static void main(String[] args) {
        // Assume userDetails is an instance of UserDetails with values set
        UserDetails userDetails = new UserDetails();
        userDetails.setId(1L);
        userDetails.setUsername("john.doe");
        userDetails.setPassword("secret");
        userDetails.setEmail("john.doe@example.com");
        userDetails.setSpecialization("Cardiology");
        userDetails.setQualification("MD");
        userDetails.setExperience(5);
        userDetails.setRole("Doctor");
        userDetails.setGender("Male");
        userDetails.setAge(35);

        // Convert UserDetails to JSON
        String userDetailsJson = convertUserDetailsToJson(userDetails);

        // Print the JSON representation
        System.out.println(userDetailsJson);
    }

    private static String convertUserDetailsToJson(UserDetails userDetails) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(userDetails);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
