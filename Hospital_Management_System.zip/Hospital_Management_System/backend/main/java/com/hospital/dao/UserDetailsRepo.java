package com.hospital.dao;

import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hospital.entity.UserDetails;

import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface UserDetailsRepo extends JpaRepository<UserDetails, Long>{

	Optional<UserDetails> findByUsername(String username);;

}
