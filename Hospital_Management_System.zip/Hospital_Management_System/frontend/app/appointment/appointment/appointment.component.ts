import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserServiceService } from 'src/app/services/user-service.service';

declare var Razorpay: 
new (arg0: any) => any
@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent {
  appointmentForm: FormGroup;
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AppointmentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private userservice:UserServiceService
    ){
    this.appointmentForm = this.fb.group({
      doctorId:[''],
      patientId:[''],
      paymentStatus:[''],
      
      status:[''],
      curedis:[''],
      appoitmentDate:['',Validators.required],
    });
  }

  makeAppointmen(){

    

    this.userservice.createTransaction(500).subscribe(
      resp=>{
        console.log('payment resp'+resp);
        this.appointmentForm.get('paymentStatus')?.setValue(500);
        this.appointmentForm.get('status')?.setValue('book');
        this.appointmentForm.get('patientId')?.setValue(this.data.patientId);
        this.appointmentForm.get('doctorId')?.setValue(this.data.doctorId);
        this.saveAppointment(this.appointmentForm.value);
        this.openTransactionModal(resp); 
    },
    error=>{
      this.appointmentForm.get('paymentStatus')?.setValue(0);
      this.appointmentForm.get('status')?.setValue('pending');
      this.appointmentForm.get('patientId')?.setValue(this.data.patientId);
      this.appointmentForm.get('doctorId')?.setValue(this.data.doctorId);
      this.saveAppointment(this.appointmentForm.value);
    }
    );
     
  }

  saveAppointment(data:any){
    this.userservice.saveAppointment(this.appointmentForm.value).subscribe(res=>{
      console.log("appointmne saved");
    })
  }

  onCancelClick(): void {
    // Close the dialog when the "Cancel" button is clicked
    this.dialogRef.close();
  }


  openTransactionModal(response:any) 
 { var options={ order_id: response.orderId, 
key:response.key, amount:response.amount, 
currency:response.currency, name:'Galaxy Hospital', 
description:'Payment gateway check', 
image:'https://cdn.pixabay.com/photo/2023/05/28/03/34/flowers8022731_640.jpg', handler:
(response:any) =>{ 
this.processResponse(response); 
 }, prefill:{ 
name:'prashant khomane', 
email:'prashantkhomane@gmail.com', 
contact:'9887867746', 
 }, notes:{ 
address:'Online Shopping'
 }, 
theme:{ 
 color:'#F37254'
 } 
 }; 
var razorPayObject=new
Razorpay(options); 
razorPayObject.open(); 
 } 
processResponse(resp:any) 
 { 
 console.log(resp); 
 }
}


