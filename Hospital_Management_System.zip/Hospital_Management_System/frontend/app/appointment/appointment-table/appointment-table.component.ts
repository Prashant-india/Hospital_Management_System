import { AfterViewInit, Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Appointment } from 'src/app/model/appointment';

@Component({
  selector: 'app-appointment-table',
  templateUrl: './appointment-table.component.html',
  styleUrls: ['./appointment-table.component.css']
})
export class AppointmentTableComponent implements AfterViewInit,OnChanges{
  @Input("appointments") appointments:Appointment[]=[];
  displayedColumns: string[] = ['srno', 'patientId', 'doctorId', 'description', 'status', 'payment'];
  dataSource = new MatTableDataSource<Appointment>(this.appointments);
  constructor(){
    console.log('data in table'+JSON.stringify(this.appointments))
  }
  ngAfterViewInit(): void {
    console.log(' afet data in table'+JSON.stringify(this.appointments))
    this.dataSource.data=this.appointments;
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.dataSource.data=this.appointments;
  }
}
