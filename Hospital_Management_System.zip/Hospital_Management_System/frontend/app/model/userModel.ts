export interface UserDetails{
    id:number;
    username:string;
    password:string
    email:string;
	specialization:string;
	qualification:string;
	experience:number;
	 role:string;
	 gender:string;
	 age:number;
}