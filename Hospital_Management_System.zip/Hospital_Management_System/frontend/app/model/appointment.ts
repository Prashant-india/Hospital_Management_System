export interface Appointment{
     id:number,
	 doctorId:number,
	 patientId:number,
	 paymentStatus:string,
	 status:string,
	 curedis:string,
	appoitmentDate:Date,
}