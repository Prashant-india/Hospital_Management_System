import { Component, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { UserDetails } from 'src/app/model/userModel';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  @ViewChild('sidenav') sidenav?: MatSidenav;
  isExpanded = true;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  loginuserDetails?:UserDetails|null;

  constructor(private userServie:UserServiceService,private router:Router){
userServie.getloginUserDetails().subscribe(
  details=>{
    if(details)
    this.loginuserDetails=details;
  }
)
  }
  logout(){
    this.userServie.logout();
    this.loginuserDetails=null;
    this.router.navigateByUrl("/home");
  }
  mouseenter() {
    if (!this.isExpanded) {
      this.isShowing = true;
    }
  }

  mouseleave() {
    if (!this.isExpanded) {
      this.isShowing = false;
    }
  }
}
