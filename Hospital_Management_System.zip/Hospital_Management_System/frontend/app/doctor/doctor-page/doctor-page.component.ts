import { Component } from '@angular/core';
import { Appointment } from 'src/app/model/appointment';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-doctor-page',
  templateUrl: './doctor-page.component.html',
  styleUrls: ['./doctor-page.component.css']
})
export class DoctorPageComponent {
  appointments:Appointment[]=[];

  constructor(private userService:UserServiceService){
    userService.getloginUserDetails().subscribe(data=>{
      data?.id;
      if(data?.id)
      userService.getAppointmentsForDoctor(data?.id).subscribe(
        aptData=>{
        this.appointments=aptData;
        }
      )
    })
    
  }

}
