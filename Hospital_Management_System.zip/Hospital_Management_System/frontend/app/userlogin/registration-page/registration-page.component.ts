import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-registration-page',
  templateUrl: './registration-page.component.html',
  styleUrls: ['./registration-page.component.css']
})
export class RegistrationPageComponent implements OnInit{
  registrationForm: FormGroup;

  constructor(private fb: FormBuilder,private userService:UserServiceService,private router:Router) {
    this.registrationForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      age: ['', Validators.required],
      gender: ['', Validators.required],
      role: ['', Validators.required],
      specialization: [''], // Added specification field
      qualification: [''], // Added qualification field
      experience: [''], // Added experience field
      pic:['']
     
    });

    // Set validators for additional fields when the role is a doctor
    this.registrationForm.get('role')?.valueChanges.subscribe((role) => {
      if (role === 'doctor') {
        this.registrationForm.get('specialization')?.setValidators(Validators.required);
        this.registrationForm.get('qualification')?.setValidators(Validators.required);
        this.registrationForm.get('experience')?.setValidators(Validators.required);
      } else {
        this.registrationForm.get('specialization')?.clearValidators();
        this.registrationForm.get('qualification')?.clearValidators();
        this.registrationForm.get('experience')?.clearValidators();
      }

      this.registrationForm.get('specialization')?.updateValueAndValidity();
      this.registrationForm.get('qualification')?.updateValueAndValidity();
      this.registrationForm.get('experience')?.updateValueAndValidity();
    });
  }

  ngOnInit() {}

  onFileChnage(event:any){
    const file: File = event.target.files[0];
  }
  uploadFile() {
    const fileInput = document.getElementById('fileInput');
    
    const file = (fileInput as HTMLInputElement).files?[0]:null;
    this.registrationForm.get('pic')?.setValue(file);
       
  }

  register() {
    // Add your registration logic here
    if (this.registrationForm.valid) {

      this.userService.registration(this.registrationForm.value).subscribe(result=>{
        if(result!=null){
          
            this.router.navigateByUrl("/login-page");
        }
      });
      console.log('Form submitted successfully!');
      console.log('Form values:', this.registrationForm.value);
      // You can implement registration logic here
    }
  }
}
