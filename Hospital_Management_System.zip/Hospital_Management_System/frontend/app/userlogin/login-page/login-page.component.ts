import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent {
  loginForm:FormGroup;
  
  constructor(private fb: FormBuilder,private userService:UserServiceService,private router:Router) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  login() {

    this.userService.login(this.loginForm.get('username')?.value,this.loginForm.get('password')?.value).subscribe(result=>{
      if(result){
        this.userService.updateloginUserDetails(result);
        this.router.navigateByUrl("/home");
      }
      console.log('user is login'+result);
    });
    // Add your login logic here
    console.log('Username:', this.loginForm.get('username')?.value);
    console.log('Password:', this.loginForm.get('password')?.value);
    // You can implement authentication logic here
  }
}
