import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { NavbarComponent } from './navbar/navbar/navbar.component';
import { DoctorPageComponent } from './doctor/doctor-page/doctor-page.component';
import { PatientPageComponent } from './patient/patient-page/patient-page.component';
import { DashboardPageComponent } from './dashboard/dashboard-page/dashboard-page.component';
import { LoginPageComponent } from './userlogin/login-page/login-page.component';
import { RegistrationPageComponent } from './userlogin/registration-page/registration-page.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http';
import { AppointmentComponent } from './appointment/appointment/appointment.component';
import { AppointmentTableComponent } from './appointment/appointment-table/appointment-table.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DoctorPageComponent,
    PatientPageComponent,
    DashboardPageComponent,
    LoginPageComponent,
    RegistrationPageComponent,
    AppointmentComponent,
    AppointmentTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatInputModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
