import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { PatientPageComponent } from './patient/patient-page/patient-page.component';
import { DoctorPageComponent } from './doctor/doctor-page/doctor-page.component';
import { DashboardPageComponent } from './dashboard/dashboard-page/dashboard-page.component';
import { LoginPageComponent } from './userlogin/login-page/login-page.component';
import { RegistrationPageComponent } from './userlogin/registration-page/registration-page.component';

const routes: Routes = [
  {path:'home',component:DashboardPageComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'patient-page',component:PatientPageComponent},
  {path:'doctor-page',component:DoctorPageComponent},
  {path:'login-page',component:LoginPageComponent},
  {path:'registration-page',component:RegistrationPageComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
