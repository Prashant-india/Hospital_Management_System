import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppointmentComponent } from 'src/app/appointment/appointment/appointment.component';
import { Appointment } from 'src/app/model/appointment';
import { UserDetails } from 'src/app/model/userModel';
import { UserServiceService } from 'src/app/services/user-service.service';

@Component({
  selector: 'app-patient-page',
  templateUrl: './patient-page.component.html',
  styleUrls: ['./patient-page.component.css']
})
export class PatientPageComponent {
 appointments:Appointment[]=[];
  patientDetails?:UserDetails;
doctorList:UserDetails[]=[];
constructor(private userService:UserServiceService,private dialog: MatDialog){
  userService.getAllUsers().subscribe(users=>{
    this.doctorList=users.filter(user=>user.role==='doctor');
  });
  userService.getloginUserDetails().subscribe(user=>{
    if(user)
    this.patientDetails=user;
  })
}

openPopup(doc:UserDetails) {
  this.dialog.open(AppointmentComponent,{
    data:{
      doctorId:doc.id,
      patientId:this.patientDetails?.id
    }
  }).afterClosed().subscribe(response=>{
    console.log('calling after close');
    if(this.patientDetails?.id)
    this.userService.getAppointmentsForPatient(this.patientDetails?.id).subscribe(
  resp=>{
this.appointments=resp;
console.log('calling after close'+JSON.stringify(resp));
  }
      );
  });
}

}
