import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { UserDetails } from '../model/userModel';
import { Appointment } from '../model/appointment';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  private apiUrl = 'http://localhost:8080/';
  private loginUserDetails = new BehaviorSubject<UserDetails|null>(null);
  constructor(private http: HttpClient) { }

  getAllUsers(): Observable<UserDetails[]> {
    return this.http.get<UserDetails[]>(this.apiUrl+'getAllUsers');
  }

  getUserDetailsById(id:number): Observable<UserDetails> {
    return this.http.get<UserDetails>(this.apiUrl+'getUsersDetailsById/'+id);
  }
  registration(userdetails:UserDetails): Observable<any> {
    return this.http.post<any>(this.apiUrl+'registration',userdetails);
  }

  login(userName:string,password:string){
    let userDetails ={
      userName:userName,
      password:password
    }
    return this.http.post<any>(this.apiUrl+'login',userDetails);
  }
  logout(){
    
    this.loginUserDetails.next(null);
  }
  updateloginUserDetails(newData: UserDetails) {
    this.loginUserDetails.next(newData);
  }
  getloginUserDetails(){
    return this.loginUserDetails;
  }

  saveAppointment(appointmentDetails:any): Observable<any>{
    return this.http.post<any>(this.apiUrl+'saveAppointment',appointmentDetails);
  }

  getAppointmentsForPatient(patientId:number): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(this.apiUrl+'getAppointmentsForPatient/'+patientId);
  }
  getAppointmentsForDoctor(doctorId:number): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(this.apiUrl+'getAppointmentsForDoctor/'+doctorId);
  }
  createTransaction(amount:number):Observable<any>{
    return this.http.get(this.apiUrl+'getTransaction/'+amount);
  }
}
